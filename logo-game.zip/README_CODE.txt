The code contains a React.js application built using "create-react-app" and "react-beautiful-dnd" NPM modules.

To run the code, open the link "i-want-to-play-a-game" in Browser (Chrome)

The folder does not include the "node_modules" directory.

For development, open the code folder in IDE like Visual Studio Code and run:
1. npm install
2. npm run start

Then the game application should be accessible from your Browser (Chrome) at 
	http://localhost:3000 