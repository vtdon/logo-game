import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { LogoGameMainView } from './main-view';

function App() {
  return (
    <LogoGameMainView></LogoGameMainView>
  );
}

export default App;
